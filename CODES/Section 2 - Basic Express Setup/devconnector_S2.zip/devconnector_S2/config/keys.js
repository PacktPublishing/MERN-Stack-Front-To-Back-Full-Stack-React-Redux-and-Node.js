module.exports = {
  mongoURI: 'mongodb://brad:brad@ds231725.mlab.com:31725/devconnector'
};
